# Kiosk Job Board Application

A fully offline, **touch-optimized job board web app** for 65” floor-standing digital signage kiosks (portrait, 1080x1920). Built for Android 11 kiosk hardware with IR touch, USB upload, and no server required.

---

## Features

- **Portrait UI (1080x1920), large modern components, #004FED primary color**
- Sticky datetime header, logo support, fullscreen button
- Scrollable, filterable job cards with QR codes (link to Apply URL)
- Touch/focus-friendly job detail pages
- Real-time client-side filtering/search (industry, title, location, gender)
- PIN-protected admin modal: Excel upload (SheetJS), export, logo upload, log
- All jobs/data stored in browser (IndexedDB/localStorage), runs offline
- Auto-scroll resumes after 30s idle (stops on touch)
- QR codes generated client-side (QRCode.js)
- Ultra lightweight, single-file deploy (HTML+JS+CSS)
- Future-proofed for kiosk camera access

---

## Admin Excel Format

| Job ID | Job Title     | Industry | Gender | Location | Posts | Description                      | Apply URL                      |
|--------|---------------|----------|--------|----------|-------|----------------------------------|-------------------------------|
| JB001  | Cashier       | Retail   | Female | Yangon   | 5     | Responsible for sales and POS.   | https://forms.gle/example     |
| JB002  | Marketing Exec| Marketing| Any    | Mandalay | 3     | Handle campaigns and social ads. | https://forms.gle/example2    |

- **Job ID auto-generated if not present**

---

## How to Deploy

1. **Develop**: Use [Replit](https://replit.com/), [CodeSandbox](https://codesandbox.io/), or [Glitch](https://glitch.com/) for live preview.
2. **Export**: Download the final `index.html` and all assets.
3. **Deploy**: Copy to your Android kiosk (via USB or LAN) and open in the kiosk browser/CMS.
4. **Admin**: Tap the hidden logo zone (or triple tap header) to open the admin panel. Enter PIN (default: `1234`), upload Excel, set logo, etc.

---

## Tech Stack

- Pure HTML5, CSS3, JavaScript (no build step needed)
- [SheetJS](https://sheetjs.com/) for Excel import/export (CDN)
- [QRCode.js](https://github.com/davidshimjs/qrcodejs) (CDN)
- [idb-keyval](https://github.com/jakearchibald/idb-keyval) for IndexedDB (CDN, optional)
- Works 100% offline (PWA/Service Worker optional)

---

## Hardware

- 65” 1080x1920 IR Touch Android Kiosk (Android 11, 2+32GB)
- USB upload support
- Built-in camera support for future expansion

---

## Customization

- Change PIN, colors, logo, etc., via admin panel or config section in code.
- All UI text and Excel columns are easily editable.

---

## License

MIT License. Use freely for commercial or non-commercial kiosks.